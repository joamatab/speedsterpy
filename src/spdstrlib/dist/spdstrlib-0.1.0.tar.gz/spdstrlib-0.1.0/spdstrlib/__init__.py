__version__ = '0.1.0'
__description__ = "Speedster project library management tool."
__date__ = "2022-04-12"
__author__ = "Diogo André Silvares Dias"
__annotations__ = ""

from spdstrlib import *