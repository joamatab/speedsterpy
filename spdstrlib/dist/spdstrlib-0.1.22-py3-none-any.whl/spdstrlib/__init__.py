__version__ = '0.1.22'
__description__ = "Speedster project library management tool."
__date__ = "2022-04-12"
__author__ = "Diogo André Silvares Dias"
__annotations__ = ""

import argparse
import sys
from loguru import logger
import pickle
import os
from .read import (
    load,
    read
)
from .write import(
    dump,
    write
)
from .util import *
from .data import *


#create the global workspace lib path save

__workspace_lib_path__ = "{}/wslib".format(getParent(os.getcwd(),1))
if not os.path.exists(__workspace_lib_path__):
    os.makedirs(__workspace_lib_path__)
__workspace_filename__ = "wslib.bin"


def verboseInfo():
    print("Version      : {} ({})".format(__version__, __date__))
    print("Authors      : {}".format(__author__))
    print("Description  : {}".format(__description__))

__arg_to_func__ = {
    SelectedOp.CREATE   : handleCreation,
    SelectedOp.DELETE   : handleDeletion,
    SelectedOp.SHOW     : handleShow,
    SelectedOp.LIST     : handleList,
}

def run(subparser, *args, **kwargs) -> None:
    logger.info("Speedster$\nLibrary Manager : {}".format(__file__))
    argv = None
    try:
        argv = subparser.parse_args(sys.argv[2:])
    except Exception as e:
        logger.error("{} - {}".format(e.__class__.__name__, e))
    if argv.info:
        verboseInfo()
        return None
    
    # load the workspace library
    libPath = os.path.join(__workspace_lib_path__, __workspace_filename__)
    lib = None
    try:
        lib = load(libPath)
    except FileNotFoundError:
        logger.info("Workspace library not found. Creating a new one.")
        # create new library on default path
        lib = SpdstrWorkspaceLib(
            libPath= __workspace_lib_path__,
            fileName= __workspace_filename__
        )
        # dump the library on the standard path
        dump(lib)    
    
    #handle mutually exclusive arguments
    try:
        arg = handleMutuallyExclusive(argv)
        __arg_to_func__[arg](argv, lib)
    except Exception as e:
        logger.error(e)
    # dump the library on the standard path
    dump(lib)
    