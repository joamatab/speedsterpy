# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['spdstrres']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=6.0,<7.0',
 'gdspy>=1.6.11,<2.0.0',
 'loguru>=0.6.0,<0.7.0',
 'networkx>=2.7.1,<3.0.0',
 'numpy>=1.22.3,<2.0.0',
 'spdstrlib @ /Users/dasdias/Documents/SoftwareProjects/speedsterpy/spdstrlib',
 'spdstrutil @ '
 '/Users/dasdias/Documents/SoftwareProjects/speedsterpy/spdstrutil']

setup_kwargs = {
    'name': 'spdstrres',
    'version': '0.1.2',
    'description': 'Speedster point-to-point resistance extraction tool.',
    'long_description': None,
    'author': 'dasdias',
    'author_email': 'das.dias6@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
