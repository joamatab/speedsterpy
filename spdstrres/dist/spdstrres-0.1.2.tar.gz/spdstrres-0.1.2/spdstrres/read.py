"""_summary_
read.py contains the main functionalities 
for the import of the developed data structures
during parasitic resistance extraction,
and saved in memory in YAML format

[author]    Diogo André Silvares Dias
[date]      2022-04-17
[contact]   das.dias@campus.fct.unl.pt
"""
