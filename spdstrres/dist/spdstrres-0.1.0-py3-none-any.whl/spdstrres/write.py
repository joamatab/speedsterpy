"""_summary_
write.py contains the main functionalities 
for the export of the developed data structures
during parasitic resistance extraction to YAML format

[author]    Diogo André Silvares Dias
[date]      2022-04-17
[contact]   das.dias@campus.fct.unl.pt
"""
import yaml
import os
from data import(
    GdsTable,
)

def writeGdsTable(tab: GdsTable, filePath: str) -> None:
    path = os.path.abspath(filePath)
    if not os.path.isdir(path):
        raise ValueError("Invalid directory path provided")
    with open(filePath, "w") as yamlFile:
        yaml.dump(tab.__dict__(), yamlFile)
