"""_summary_
read.py contains the main functionalities 
for the import of the developed data structures
during parasitic resistance extraction,
and saved in memory in YAML format

[author]    Diogo André Silvares Dias
[date]      2022-04-17
[contact]   das.dias@campus.fct.unl.pt
"""
import yaml
import csv
import pickle
import os
from data import(
    GdsLayerPurpose,
    GdsTable,
)

def readGdsTable(filePath = "") -> GdsTable:
    """_summary_
    Reads the gds table
    Args:
        fileName (str, optional): _description_. Defaults to "".

    Raises:
        ValueError: _description_
    """
    
    if filePath == "":
        raise ValueError("No file name provided")
    
    path = os.path.abspath(filePath)
    if not os.path.isfile(path):
        raise ValueError("Invalid file path provided")
    
    head, tail = os.path.split(path)
    filename, extension = os.path.splitext(tail)
    if extension != ".csv" and extension != ".yaml":
        raise ValueError("Invalid format provided: accepts \"json\" or \"csv\"")
    
    # declare a new empty gds table
    gdsTable = GdsTable()
    if extension == ".csv":
        header = {
                "Layer name"        : 0,
                "Purpose"           : 1,
                "GDS layer:datatype": 2,
                "Description"       : 3
            }
        with open(path, "r") as csvFile:
            file = csv.reader(csvFile)
            #establish the heard order
            line = file[0]
            for i,identifier in enumerate(line, 0):
                header[identifier] = i
            
            for line in file[1:]:
                # preprocessing of the lines
                #preprocess purpose line
                splits = line[ header["Purpose"] ].split(',')
                purposes = []
                for split in splits:
                    split.remove(' ')
                    if split != "":
                        purposes.append(GdsLayerPurpose(split))
                #preprocess layer:datatype line
                splits = line[ header["GDS layer:datatype"] ].split(':')
                layer = int(splits[0])
                datatype = int(splits[1])
                gdsTable.add(
                    layer=layer,
                    dataType=datatype,
                    name=line[ header["Layer name"] ],
                    purpose=purposes,
                    description=line[ header["Description"] ].remove('\n')
                )
    else:# extension == ".yaml":
        with open(path, "r") as yamlFile:
            gdsTableDict = yaml.load(yamlFile, Loader=yaml.FullLoader)
        gdsTable.parseData(gdsTableDict)
    return gdsTable