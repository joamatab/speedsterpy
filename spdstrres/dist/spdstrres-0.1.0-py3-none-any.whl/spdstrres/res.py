"""_summary_
res.py contains the main algorithms for the
computation of the point to point resistance
networks throughout all the IC layout 

[author]    Diogo André Silvares Dias
[date]      2022-04-17
[contact]   das.dias@campus.fct.unl.pt
"""