"""_summary_
layout.py contains the main functionalities 
for the preprocessing of the IC layout gds information

[author]    Diogo André Silvares Dias
[date]      2022-04-17
[contact]   das.dias@campus.fct.unl.pt
"""