"""_summary_
write.py contains the main functionalities 
for the export of the developed data structures
during parasitic resistance extraction to YAML format

[author]    Diogo André Silvares Dias
[date]      2022-04-17
[contact]   das.dias@campus.fct.unl.pt
"""