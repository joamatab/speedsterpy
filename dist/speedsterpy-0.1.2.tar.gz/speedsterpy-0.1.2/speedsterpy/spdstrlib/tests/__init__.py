from test_spdstr_lib import *

test_version()

test_workspace_lib_creation()

test_workspace_creation()

test_workspace_write()

test_workspace_read()
