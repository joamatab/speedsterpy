# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['speedsterpy',
 'speedsterpy.spdstrcap.spdstrcap',
 'speedsterpy.spdstrcap.tests',
 'speedsterpy.spdstrlib.spdstrlib',
 'speedsterpy.spdstrlib.tests',
 'speedsterpy.spdstrpower.spdstrpower',
 'speedsterpy.spdstrpower.tests',
 'speedsterpy.spdstrres.spdstrres',
 'speedsterpy.spdstrres.tests']

package_data = \
{'': ['*'],
 'speedsterpy': ['spdstrcap/*',
                 'spdstrlib/README.md',
                 'spdstrlib/README.md',
                 'spdstrlib/README.md',
                 'spdstrlib/README.rst',
                 'spdstrlib/README.rst',
                 'spdstrlib/README.rst',
                 'spdstrlib/dist/*',
                 'spdstrlib/pyproject.toml',
                 'spdstrlib/pyproject.toml',
                 'spdstrlib/pyproject.toml',
                 'spdstrlib/resources/*',
                 'spdstrlib/resources/temp/*',
                 'spdstrlib/resources/temp/testbench/*',
                 'spdstrlib/resources/temp2/*',
                 'spdstrpower/*',
                 'spdstrres/*',
                 'spdstrres/dist/*']}

install_requires = \
['deflefpy>=0.1.3,<0.2.0',
 'gdspy>=1.6.11,<2.0.0',
 'loguru>=0.6.0,<0.7.0',
 'networkx>=2.7.1,<3.0.0',
 'toml>=0.10.2,<0.11.0']

setup_kwargs = {
    'name': 'speedsterpy',
    'version': '0.1.2',
    'description': 'Speedster - A 3D point to point parasitic resistance extraction tool for Integrated Circuits',
    'long_description': None,
    'author': 'Diogo Andre',
    'author_email': 'das.dias6@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/das-dias/speedsterpy',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
